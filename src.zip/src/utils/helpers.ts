import { TipoMovimentacao } from '../models/tipoMovimentacao.model';
import { TipoEntradaSaida } from '../models/tipoEntradaSaida.model';

export async function getTipoMovimentacaoId(nome: string): Promise<number> {
  const tipo = await TipoMovimentacao.findOne({ where: { nome } });
  if (!tipo) throw new Error(`Tipo de movimentação '${nome}' não encontrado.`);
  return tipo.id;
}

export async function getTipoEntradaSaidaId(nome: string): Promise<number> {
  const tipo = await TipoEntradaSaida.findOne({ where: { nome } });
  if (!tipo) throw new Error(`Tipo de entrada/saída '${nome}' não encontrado.`);
  return tipo.id;
}
