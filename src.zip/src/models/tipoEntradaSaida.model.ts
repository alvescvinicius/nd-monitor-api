import { Table, Column, Model, DataType, PrimaryKey, Unique, HasMany } from 'sequelize-typescript';
import { Transacao } from './transacao.model';

@Table({ tableName: 'tipos_entrada_saida', timestamps: false })
export class TipoEntradaSaida extends Model {
  @PrimaryKey
  @Column(DataType.TINYINT)
  id!: number;

  @Unique
  @Column(DataType.STRING)
  nome!: string;

  @HasMany(() => Transacao)
  transacoes!: Transacao[];
}
