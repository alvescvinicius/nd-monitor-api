import { Table, Column, Model, DataType, PrimaryKey, AutoIncrement, Unique, HasMany } from 'sequelize-typescript';
import { Transacao } from './transacao.model';

@Table({ tableName: 'instituicoes', timestamps: false })
export class Instituicao extends Model {
  @PrimaryKey
  @AutoIncrement
  @Column(DataType.INTEGER)
  id!: number;

  @Unique
  @Column(DataType.STRING)
  nome!: string;

  @HasMany(() => Transacao)
  transacoes!: Transacao[];
}
