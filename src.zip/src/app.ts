import express from 'express';
import transacoes from './routes/transacoes.routes';

const app = express();

app.use(express.json());

app.use('/api', transacoes);

export default app;
