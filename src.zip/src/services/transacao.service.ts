import { Sequelize } from 'sequelize-typescript';
import { Transacao } from '../models/transacao.model';
import { Produto } from '../models/produto.model';
import { Instituicao } from '../models/instituicao.model';
import { TransacaoRepository } from '../repositories/transacao.repository';
import { ProdutoRepository } from '../repositories/produto.repository';
import { InstituicaoRepository } from '../repositories/instituicao.repository';

interface CriarTransacaoDTO {
  tipo_entrada_saida_id: number;
  data: Date | string;
  tipo_movimentacao_id: number;
  produto_codigo: string;
  produto_descricao: string;
  instituicao_nome: string;
  quantidade: number;
  preco_unitario: number | null;
  valor_operacao: number;
}

export class TransacaoService {
  private readonly transacaoRepository: TransacaoRepository;
  private readonly produtoRepository: ProdutoRepository;
  private readonly instituicaoRepository: InstituicaoRepository;

  constructor(private readonly sequelize: Sequelize) {
    this.transacaoRepository = new TransacaoRepository(sequelize);
    this.produtoRepository = new ProdutoRepository(sequelize);
    this.instituicaoRepository = new InstituicaoRepository(sequelize);
  }

  async listarTodas(): Promise<Transacao[]> {
    return this.transacaoRepository.findAll();
  }

  async buscarPorId(id: number): Promise<Transacao | null> {
    return this.transacaoRepository.findById(id);
  }

  async criarTransacao(data: CriarTransacaoDTO): Promise<Transacao> {
    const transaction = await this.sequelize.transaction();
    try {
      // Validação básica dos IDs numéricos para evitar null/undefined
      if (!data.tipo_entrada_saida_id) throw new Error("tipo_entrada_saida_id é obrigatório");
      if (!data.tipo_movimentacao_id) throw new Error("tipo_movimentacao_id é obrigatório");
      if (!data.valor_operacao && data.valor_operacao !== 0) throw new Error("valor_operacao é obrigatório");
      if (!data.data) throw new Error("data é obrigatória");

      // Produto: buscar ou criar
      let produto = await Produto.findOne({
        where: {
          codigo: data.produto_codigo,
          descricao: data.produto_descricao
        },
        transaction
      });

      if (!produto) {
        produto = await Produto.create({
          codigo: data.produto_codigo,
          descricao: data.produto_descricao
        }, { transaction });
      }

      // Instituição: buscar ou criar
      let instituicao = await Instituicao.findOne({
        where: { nome: data.instituicao_nome },
        transaction
      });

      if (!instituicao) {
        instituicao = await Instituicao.create({
          nome: data.instituicao_nome
        }, { transaction });
      }

      console.log(`DATA: ${JSON.stringify(data)}`);

      // Criar transação com IDs garantidos
      const novaTransacao = await Transacao.create({
        tipo_entrada_saida_id: data.tipo_entrada_saida_id,
        data: data.data,
        tipo_movimentacao_id: data.tipo_movimentacao_id,
        produto_id: produto.id,
        instituicao_id: instituicao.id,
        quantidade: data.quantidade,
        preco_unitario: data.preco_unitario,
        valor_operacao: data.valor_operacao
      }, { transaction });

      await transaction.commit();
      return novaTransacao;
    } catch (err) {
      await transaction.rollback();
      throw err;
    }
  }

  async atualizarTransacao(id: number, data: Partial<Transacao>): Promise<Transacao | null> {
    return this.transacaoRepository.update(id, data);
  }

  async deletarTransacao(id: number): Promise<boolean> {
    return this.transacaoRepository.delete(id);
  }
}
