import { Router } from 'express';
import { TransacaoController } from '../controllers/transacao.controller';

const router = Router();

router.get('/transacoes', TransacaoController.listar);
router.get('/transacoes/:id', TransacaoController.buscarPorId);
router.post('/transacoes', TransacaoController.criar);
router.put('/transacoes/:id', TransacaoController.atualizar);
router.delete('/transacoes/:id', TransacaoController.deletar);

export default router;