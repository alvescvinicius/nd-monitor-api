import { Sequelize } from 'sequelize-typescript';
import { Transacao } from '../models/transacao.model';

export class TransacaoRepository {
  constructor(private readonly sequelize: Sequelize) {}

  async findAll(): Promise<Transacao[]> {
    return Transacao.findAll({
      include: ['produto', 'instituicao', 'tipoEntradaSaida', 'tipoMovimentacao']
    });
  }

  async findById(id: number): Promise<Transacao | null> {
    return Transacao.findByPk(id, {
      include: ['produto', 'instituicao', 'tipoEntradaSaida', 'tipoMovimentacao']
    });
  }

  async create(data: Partial<Transacao>): Promise<Transacao> {
    const transaction = await this.sequelize.transaction();
    try {
      const created = await Transacao.create(data as any, { transaction });
      await transaction.commit();
      return created;
    } catch (err) {
      await transaction.rollback();
      throw err;
    }
  }

  async update(id: number, data: Partial<Transacao>): Promise<Transacao | null> {
    const transaction = await this.sequelize.transaction();
    try {
      const instance = await Transacao.findByPk(id, { transaction });
      if (!instance) {
        await transaction.rollback();
        return null;
      }
      await instance.update(data as any, { transaction });
      await transaction.commit();
      return instance;
    } catch (err) {
      await transaction.rollback();
      throw err;
    }
  }

  async delete(id: number): Promise<boolean> {
    const transaction = await this.sequelize.transaction();
    try {
      const deleted = await Transacao.destroy({ where: { id }, transaction });
      await transaction.commit();
      return deleted > 0;
    } catch (err) {
      await transaction.rollback();
      throw err;
    }
  }
}
